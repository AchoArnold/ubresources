list p=16f84, f=inhx8m, r=dec
	#include <p16f84.inc>
    __config _CP_OFF & _WDT_OFF & _XT_OSC 

#DEFINE			LED2	PORTB,2 
N1 				equ 	0Ch
N2    			equ 	0Dh
N3 				equ 	0Eh

ORG 00

     			bsf     STATUS,RP0			;bank1
     			clrf    TRISB
    			bcf     STATUS,RP0			;bank0
     			clrf    PORTB
   
start 			movlw   63
     			movwf   PORTB
				call    delay
    		 	movlw   79
     			movwf   PORTB
				call 	delay
				movlw   91
				movwf   PORTB
				call 	delay
			    movlw   125
				movwf   PORTB
				call 	delay
				movlw   111
				movwf   PORTB
				call    delay
				movlw   6
				movwf   PORTB
				call    delay
		        goto    start

delay
		 		movlw   200
		 		movwf   N1
		 		movlw   200
		 		movwf   N2 
		 		movlw   5
		 		movwf   N3

Loop        	decfsz  N1,1
		     	goto    Loop
		     	decfsz  N2,1
		     	goto    Loop
		     	decfsz  N3,1
		     	goto     Loop
				
				return
			  
end
